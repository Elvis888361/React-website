import React from 'react';
import '../../App.css';
import signUp from '../SignUp';


function Sign() {
  return (
    <>
      <signUp/>
    </>
  );
}

export default Sign;
